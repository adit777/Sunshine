package com.example.adityaa.perkiraancuaca.data;

/**
 * Created by Aditya A on 01/05/2017.
 */

public class ModelWeather {
    long dateTime;

    double pressure;

    int humidity;

    double windSpeed;

    double windDirection;



    double high;

    double low;



    String description;

    int weatherId;



    public long getDateTime() {

        return dateTime;

    }



    public void setDateTime(long dateTime) {

        this.dateTime = dateTime;

    }



    public double getPressure() {

        return pressure;

    }



    public void setPressure(double pressure) {

        this.pressure = pressure;

    }



    public int getHumidity() {

        return humidity;

    }



    public void setHumidity(int humidity) {

        this.humidity = humidity;

    }



    public double getWindSpeed() {

        return windSpeed;

    }



    public void setWindSpeed(double windSpeed) {

        this.windSpeed = windSpeed;

    }



    public double getWindDirection() {

        return windDirection;

    }



    public void setWindDirection(double windDirection) {

        this.windDirection = windDirection;

    }



    public double getHigh() {

        return high;

    }



    public void setHigh(double high) {

        this.high = high;

    }



    public double getLow() {

        return low;

    }



    public void setLow(double low) {

        this.low = low;

    }



    public String getDescription() {

        return description;

    }



    public void setDescription(String description) {

        this.description = description;

    }



    public int getWeatherId() {

        return weatherId;

    }


    public void setWeatherId(int weatherId) {

        this.weatherId = weatherId;

    }

}
